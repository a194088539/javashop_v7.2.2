package com.enation.coder.controller.data;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.enation.coder.model.po.DataModel;
import com.enation.coder.model.vo.GenerateParam;
import com.enation.coder.service.IDataModelManager;
import com.enation.coder.util.FileToZip;
import com.enation.framework.database.Page;

/**
 * Created by kingapex on 12/02/2018.
 * 用户数据控制器
 * @author kingapex
 * @version 1.0
 * @since 6.4.0
 * 12/02/2018
 */
@RestController
@RequestMapping("/data")
@Validated
public class DataModelDataController {

    @Autowired
    private IDataModelManager dataModelManager;

    @GetMapping("/project/{project_id}/model")
    public Page<DataModel> list(int page_no, int page_size,@PathVariable int project_id){
    	
        return  dataModelManager.list(page_no,page_size,project_id);
    }


    /**
     * 添加模型
     * @param project
     * @return
     */
    @PostMapping("/project/{project_id}/model")
    public DataModel add(@Valid DataModel dataModel,@PathVariable int project_id){
    	
    	dataModel.setProject_id(project_id);
    	dataModel = dataModelManager.add(dataModel);
    	
        return  dataModel;
    }

    /**
     * 修改模型信息
     * @param customer_id
     * @param customer
     * @return
     */
    @PostMapping("/project/{project_id}/model/{model_id}")
    public DataModel edit(@PathVariable("project_id") int project_id ,@Valid DataModel dataModel,@PathVariable("model_id") int model_id){

    	dataModel.setModel_id(model_id);
    	dataModel.setProject_id(project_id);
    	dataModelManager.edit(dataModel);

        return  dataModel;
    }

    /**
     * 获取一个模型信息
     * @param customer_id
     * @return
     */
    @GetMapping("/project/{project_id}/model/{model_id}")
    public  DataModel get(@PathVariable("project_id") int project_id,@PathVariable("model_id") int model_id ){
    	
    	DataModel model = dataModelManager.get(model_id);
    	
        return model;
    }

    /**
     * 删除一个模型信息
     * @param customer_id
     */
    @DeleteMapping("/project/{project_id}/model/{model_id}")
    public void delete(@PathVariable("project_id") int project_id,@PathVariable("model_id") int model_id){
    	
    	dataModelManager.delete(model_id);
    }

    /**
     * 生成代码
     * @param project_id
     * @param model_id
     */
    @GetMapping("/project/model/{model_id}/generate")
    public void generate(@PathVariable("model_id") int model_id,GenerateParam params){
    	
    	params.setModelId(model_id);
    	
    	dataModelManager.generate(params);
    	
    }
    
    /**
     * 下载代码
     * @param project_id
     * @param model_id
     */
    @GetMapping("/project/model/{model_id}/download")
    public HttpServletResponse download(@PathVariable("model_id") int model_id,HttpServletResponse response){
    	
    	try {
            
            File file = dataModelManager.download(model_id);
            
            response.reset();
            return FileToZip.downloadZip(file, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
       
        return response;
    }
    
   /**
    * 生成sql
    * @param model_id
    * @return
    */
    @GetMapping("/project/model/{model_id}/sql")
    public String generateSql(@PathVariable("model_id") int model_id){
    	
    	return this.dataModelManager.getSql(model_id);
    }
    
    
    


}
