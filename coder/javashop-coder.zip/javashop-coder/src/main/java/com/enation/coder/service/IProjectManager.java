package com.enation.coder.service;

import com.enation.coder.model.po.Project;
import com.enation.framework.database.Page;

/**
 * 项目业务类
 * @author fk
 * @version v1.0
 * @since v7.0
 * 2018年3月9日 上午9:17:18
 */
public interface IProjectManager
{

    /**
     * 分页查询项目列表
     * @param pageNo
     * @param pageSize
     * @return
     */
    Page<Project> list(int pageNo, int pageSize);


    /**
     * 添加一个项目
     * @param customer
     * @return
     */
    Project add(Project project);

    /**
     * 修改一个项目
     * @param project_id
     * @param project
     * @return
     */
    Project edit(int project_id, Project project);

    /**
     * 获取一个项目实例
     * @param project_id
     * @return
     */
    Project get(int project_id);

    /**
     * 删除一个项目
     * @param project_id
     */
    void delete(int project_id);

}
