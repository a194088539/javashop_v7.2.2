package com.enation.coder.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.enation.coder.model.po.AdminUser;
import com.enation.coder.model.po.Project;
import com.enation.coder.service.IAdminUserManager;
import com.enation.coder.service.IProjectManager;
import com.enation.framework.database.IDaoSupport;
import com.enation.framework.database.Page;
import com.enation.framework.util.DateUtil;
import com.enation.framework.util.JsonUtil;

/**
 * Created by kingapex on 13/02/2018.
 * 客户业务管理实现类
 * @author kingapex
 * @version 1.0
 * @since 6.4.0
 * 13/02/2018
 */
@Service
public class ProjectManagerImpl implements IProjectManager {


    @Autowired
    private IDaoSupport daoSupport;
    
    @Autowired
    private IAdminUserManager adminUserManager;

    /**
     * 分页查询我的项目列表
     * @param pageNo
     * @param pageSize
     * @return
     */
    @Override
    public Page<Project> list(int pageNo, int pageSize) {
    	
    	AdminUser user = adminUserManager.getCurrentUser();
    	
        String sql  ="select * from es_project  order by add_time desc";
        
        return  daoSupport.queryForPage(sql,pageNo,pageSize,Project.class);
    }

    @Override
    @Transactional
    public Project add(Project project) {
    	
    	AdminUser user = adminUserManager.getCurrentUser();
    	
    	project.setUser_id(user.getUserid());
    	project.setAdd_time(DateUtil.getDateline());
    	
    	this.daoSupport.insert("es_project", project);
    	
    	int project_id = this.daoSupport.getLastId("es_project");
    	project.setId(project_id);
    	
        return project;
    }

    private  String toJson(Project customer){
        return  JsonUtil.ObjectToJson(customer);
    }

    @Override
    @Transactional
    public Project edit(int project_id, Project project) {
    	
    	//更改项目
    	this.daoSupport.update("es_project", project, "id="+project_id);
    	
        return project;
    }

    @Override
    public Project get(int project_id) {
    	
    	Project project  = daoSupport.queryForObject("select * from es_project  where id=?",Project.class,project_id);
    	
        return project;
    }

    @Override
    @Transactional
    public void delete(int project_id) {

        daoSupport.execute("update es_customer set delete_flag=1 where customer_id=?",project_id);

    }

}
