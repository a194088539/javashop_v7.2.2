package com.enation.coder.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.tomcat.jni.Buffer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.enation.coder.config.FileConfig;
import com.enation.coder.model.enums.FiledDataType;
import com.enation.coder.model.po.AdminUser;
import com.enation.coder.model.po.DataField;
import com.enation.coder.model.po.DataModel;
import com.enation.coder.model.vo.GenerateParam;
import com.enation.coder.service.IAdminUserManager;
import com.enation.coder.service.IDataFieldManager;
import com.enation.coder.service.IDataModelManager;
import com.enation.coder.util.FileHelper;
import com.enation.coder.util.FileToZip;
import com.enation.framework.context.ThreadContextHolder;
import com.enation.framework.database.IDaoSupport;
import com.enation.framework.database.Page;
import com.enation.framework.util.DateUtil;

/**
 * 模型业务类
 * @author fk
 * @version v1.0
 * @since v7.0
 * 2018年3月9日 上午11:49:45
 */
@Service
public class DataModelManager implements IDataModelManager{

	@Autowired
	private IDaoSupport daoSupport;
	
	@Autowired
	private FileConfig fileConfig;
	
	@Autowired
    private IAdminUserManager adminUserManager;
	
	@Autowired
	private IDataFieldManager dataFieldManager;
	
	
	@Override
	public Page<DataModel> list(int pageNo, int pageSize, int project_id) {

		String sql = "select * from es_data_model where project_id = ? order by add_time desc ";
		
		return this.daoSupport.queryForPage(sql, pageNo, pageSize,DataModel.class, project_id);
	}

	@Override
	public DataModel add(DataModel dataModel) {
		
		//TODO 验证权限
		
		//查询关联的项目
//		Project project = projectManager.get(dataModel.getProject_id());
		dataModel.setAdd_time(DateUtil.getDateline());
//		dataModel.setPackage_name(project.getPackage_name());
		
		//生成表名
		String tableName = replaceUpperCase(dataModel.getEnglish_name());
		dataModel.setTable_name(tableName);
		
		this.daoSupport.insert("es_data_model", dataModel);
		int modelId = this.daoSupport.getLastId("es_data_model");
		
		dataModel.setModel_id(modelId);
		
		return dataModel;
	}

	/**
	 * 将驼峰格式的英文转成对应格式的表名
	 * @param english_name
	 * @return
	 */
	private String replaceUpperCase(String englishName) {
		
		StringBuffer tableName = new StringBuffer("es_");
		for (int i = 0; i < englishName.length(); i++) {
            if (Character.isUpperCase(englishName.charAt(i))) {//是大写
            	tableName.append("_");
            }
            tableName.append(englishName.charAt(i));
        }
		
		return  tableName.toString().toLowerCase();
	}

	@Override
	public DataModel edit(DataModel dataModel) {

		String tableName = replaceUpperCase(dataModel.getEnglish_name());
		dataModel.setTable_name(tableName);
		
		this.daoSupport.update("es_data_model", dataModel, "model_id="+dataModel.getModel_id());
		
		return dataModel;
	}

	@Override
	public DataModel get(int dataModel_id) {
		
		String  sql = "select * from es_data_model where model_id = ? ";
		
		return this.daoSupport.queryForObject(sql, DataModel.class, dataModel_id);
	}

	@Override
	public void delete(int dataModel_id) {
		
		String sql = "update es_data_model set status = 0 where model_id = ?";
		
		this.daoSupport.execute(sql, dataModel_id);
	}

	@Override
	public void generate(GenerateParam params) {
		
		DataModel model = this.get(params.getModelId());
		
		AdminUser user = adminUserManager.getCurrentUser();
		String s = model.getEnglish_name();
		String className = (new StringBuilder()).append(Character.toUpperCase(s.charAt(0))).append(s.substring(1)).toString();
		
		String fileName = fileConfig.getFilePath();
		
		//使用传递的包名做一层文件夹
		model.setChild_package_name(params.getPackageName());
		this.edit(model);
		
		
		fileName += params.getPackageName()+"/"+s.toLowerCase();
		
		FileHelper.createDirectory(fileName);
		
		try {
			//判断需要生成的文件
			String[] items = params.getGenerateItems();
			
			FileHelper.writeToFile(fileName+"/"+className+".java", this.getHTML(this.getCallUrl()+"/view/template/model/"+model.getModel_id()+"?packageName="+params.getPackageName()+"&username="+user.getUsername()));
			
			if(items!=null && items.length>0){//如果没有选择，只生成model层
				if(Arrays.asList(items).contains("service")){//生成业务层
					
					FileHelper.writeToFile(fileName+"/I"+className+"Manager.java", this.getHTML(this.getCallUrl()+"/view/template/interface/"+model.getModel_id()+"?packageName="+params.getPackageName()+"&username="+user.getUsername()));
					FileHelper.writeToFile(fileName+"/"+className+"Manager.java", this.getHTML(this.getCallUrl()+"/view/template/service/"+model.getModel_id()+"?packageName="+params.getPackageName()+"&username="+user.getUsername()));
				}
				
				if(Arrays.asList(items).contains("controller")){
					FileHelper.writeToFile(fileName+"/"+className+"Controller.java", this.getHTML(this.getCallUrl()+"/view/template/controller/"+model.getModel_id()+"?packageName="+params.getPackageName()+"&username="+user.getUsername()));
				}
			}
			
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * 传入url 返回对应页面的html
	 * 
	 * @param url  页面的url
	 * @param type  客户端类型
	 * @return 返回对应页面的html
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	private String getHTML(String url) throws ClientProtocolException, IOException {
		String html = "null";
		RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(50000) // socket超时
				.setConnectTimeout(50000) // connect超时
				.build();
		CloseableHttpClient httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).build();
		HttpGet httpGet = new HttpGet(url);
		CloseableHttpResponse response = httpClient.execute(httpGet);
		html = EntityUtils.toString(response.getEntity(), "utf-8");
		return html;
	}
	
	/**
	 * 获取地址
	 * @return
	 */
	private String getCallUrl(){
		
		HttpServletRequest request = ThreadContextHolder.getHttpRequest();
		String serverName = request.getServerName();
		int port = request.getServerPort();
		String portstr = "";
		if(port!=80){
			portstr = ":"+port;
		}
		String contextPath = request.getContextPath();
		
		return "http://"+serverName+portstr+contextPath;
	}

	@Override
	public File download(int model_id) {
		
		DataModel model = this.get(model_id);
		
		String fileName = fileConfig.getFilePath();//G:/7.0/ding/goodssku
		
		fileName += model.getChild_package_name()+"/"+model.getEnglish_name().toLowerCase();//goods/goodssku
		
		String zipPath = fileConfig.getZipFilePath()+model.getChild_package_name();
		FileHelper.createDirectory(zipPath);
		
        FileToZip.fileToZip(fileName, zipPath, model.getEnglish_name().toLowerCase());
        
        /**创建一个临时压缩文件，我们会把文件流全部注入到这个文件中，这里的文件你可以自定义是.rar还是.zip**/
        File file = new File(zipPath+"/"+model.getEnglish_name().toLowerCase()+".zip");
        if (!file.exists()) {
            try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
        }
        
        
		return file;
	}

	@Override
	public String getSql(int model_id) {
		
		DataModel model = this.get(model_id);
		List<DataField> fields = dataFieldManager.getFieldByModel(model_id);
		
//		CREATE TABLE `es_adminuser` (
//				  `userid` int(11) NOT NULL AUTO_INCREMENT,
//				  `username` varchar(255) DEFAULT NULL,
//				  `password` varchar(255) DEFAULT NULL,
//				  `state` int(6) DEFAULT NULL,
//				  `realname` varchar(255) DEFAULT NULL,
//				  `remark` varchar(255) DEFAULT NULL,
//				  `dateline` int(11) DEFAULT NULL,
//				  `role` varchar(50) NOT NULL,
//				  PRIMARY KEY (`userid`)
//				) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8
		
		StringBuffer sqlStr = new StringBuffer();
		sqlStr.append("CREATE TABLE `"+model.getTable_name()+"` ( \r\n");
		String primaryKey = "";
		for(DataField field : fields){
			sqlStr.append("`"+field.getEnglish_name()+"` "+field.getData_type().toLowerCase()+"("+field.getData_size()+")");
			if(field.getIs_primary()==1){//是主键，则自增
				primaryKey = field.getEnglish_name();
				sqlStr.append(" NOT NULL AUTO_INCREMENT,\r\n");
			}else{
				sqlStr.append(" DEFAULT NULL,\r\n");
			}
		}
		if(!"".equals(primaryKey)){
			sqlStr.append(" PRIMARY KEY (`"+primaryKey+"`)\r\n");
		}
		//结尾
		sqlStr.append(") ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ");
		
		return sqlStr.toString();
	}	

}
