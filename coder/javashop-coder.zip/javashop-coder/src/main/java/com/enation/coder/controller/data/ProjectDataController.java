package com.enation.coder.controller.data;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.enation.coder.model.po.Project;
import com.enation.coder.service.IProjectManager;
import com.enation.framework.database.Page;

/**
 * Created by kingapex on 12/02/2018.
 * 用户数据控制器
 * @author kingapex
 * @version 1.0
 * @since 6.4.0
 * 12/02/2018
 */
@RestController
@RequestMapping("/data")
@Validated
public class ProjectDataController {

    @Autowired
    private IProjectManager projectManager;

    @GetMapping("/project")
    public Page<Project> list(int page_no, int page_size ){
    	
        return  projectManager.list(page_no,page_size);
    }


    /**
     * 添加项目
     * @param project
     * @return
     */
    @PostMapping("/project")
    public Project add(@Valid Project project){
    	
    	project = projectManager.add(project);
        return  project;
    }

    /**
     * 修改客户信息
     * @param customer_id
     * @param customer
     * @return
     */
    @PostMapping("/project/{project_id}")
    public Project edit(@PathVariable("project_id") int project_id ,@Valid Project project){

    	projectManager.edit(project_id, project);

        return  project;
    }

    /**
     * 获取一个客户信息
     * @param customer_id
     * @return
     */
    @GetMapping("/project/{project_id}")
    public  Project get(@PathVariable("project_id") int project_id ){
    	
    	Project project = projectManager.get(project_id);
    	
        return project;
    }

    /**
     * 删除一个客户信息
     * @param customer_id
     */
    @DeleteMapping("/project/{project_id}")
    public void delete(@PathVariable("project_id") int project_id ){
    	projectManager.delete(project_id);
    }




}
