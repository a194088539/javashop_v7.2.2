package com.enation.coder.service.impl;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.enation.coder.model.enums.FiledDataType;
import com.enation.coder.model.enums.PowerType;
import com.enation.coder.model.po.DataField;
import com.enation.coder.model.po.DataModel;
import com.enation.coder.model.po.Project;
import com.enation.coder.model.vo.CoderParam;
import com.enation.coder.service.IDataFieldManager;
import com.enation.coder.service.IDataModelManager;
import com.enation.coder.service.IProjectManager;
import com.enation.coder.service.ITempateGenerateManager;
import com.enation.coder.util.Constants;
import com.enation.framework.util.DateUtil;
import com.enation.framework.util.StringUtil;

/**
 * 模板生成manager
 * @author fk
 * @version v1.0
 * @since v7.0
 * 2018年3月12日 下午1:59:26
 */
@Service
public class TempateGenerateManager implements ITempateGenerateManager{

	
	@Autowired
	private IProjectManager projectManager;
	
	@Autowired
	private IDataModelManager dataModelManager;
	
	@Autowired
	private IDataFieldManager dataFieldManager;
	
	@Override
	public Model generateModel(CoderParam param, Model model) {
		
    	//查询模板
		DataModel dataModel = this.dataModelManager.get(param.getModelId());
		
		//查询项目
		Project project = projectManager.get(dataModel.getProject_id());
		
		model.addAttribute("time", DateUtil.toString(new Date(), "yyyy-MM-dd HH:mm:ss"));
		
		model.addAttribute("packageStr", project.getPackage_name()+Constants.CHARACTER_POINT+PowerType.core+Constants.CHARACTER_POINT
				+param.getPackageName()+".model.po");
        model.addAttribute("username", param.getUsername());
        model.addAttribute("version", dataModel.getVersion());
        model.addAttribute("since", project.getSince());
        model.addAttribute("model", dataModel);
        String s = dataModel.getEnglish_name();
        model.addAttribute("className", (new StringBuilder()).append(Character.toUpperCase(s.charAt(0))).append(s.substring(1)).toString());

        // 生成属性，getter,setter方法
        List<DataField> fieldList = this.dataFieldManager.getFieldByModel(param.getModelId());
        
        StringBuilder sb = new StringBuilder();
        StringBuilder sbMethods = new StringBuilder();
        StringBuilder importStr = new StringBuilder();
        
        for(DataField field : fieldList){
        	
        	String propName = field.getEnglish_name();
            String propType = FiledDataType.valueOf(field.getData_type()).getType();
            
            // 注释、类型、名称
            sb.append("    /**")
                .append(field.getChina_name())
                .append("*/\r\n");
            
            if(field.getIs_primary()==1){//是主键
            	sb.append("    @Id\r\n");
            	sbMethods.append("    @PrimaryKeyField\r\n");
            	sb.append("    @ApiModelProperty(hidden=true)\r\n");
            }else{
            	sb.append("    @Column()\r\n");
            	
            	String validateItem = field.getValidate_items();//校验
            	String isEmpty = "false";
            	if(validateItem!=null){
            		switch (validateItem) {
					case "notempty"://必填
						sb.append("    @NotEmpty(message=\""+field.getChina_name()+"不能为空\")\r\n");
						isEmpty = "true";
						importStr.append("import javax.validation.constraints.NotEmpty;\r\n");
						break;
					case "number"://数字
						sb.append("    @Min(message=\"必须为数字\", value = 0)\r\n");
						importStr.append("import javax.validation.constraints.Min;\r\n");
						break;
					case "email"://邮件
						sb.append("    @Email(message=\"格式不正确\")\r\n");
						importStr.append("import javax.validation.constraints.Email;\r\n");
						break;

					default:
						break;
					}
            	}
            	
            	sb.append("    @ApiModelProperty(value=\""+field.getChina_name()+"\",required="+isEmpty+")\r\n");
            }
            
            
            sb.append("    private ")
                .append(propType)
                .append(" ")
                .append(propName)
                .append(";\r\n");

            sbMethods.append("    public ")
                .append(propType)
                .append(" get")
                .append(propName.substring(0, 1).toUpperCase())
                .append(propName.substring(1))
                .append("() {\r\n")
                .append("        return ")
                .append(propName)
                .append(";\r\n")
                .append("    }\r\n")
                .append("    public void set")
                .append(propName.substring(0, 1).toUpperCase())
                .append(propName.substring(1))
                .append("(")
                .append(propType)
                .append(" ")
                .append(propName)
                .append(") {\r\n")
                .append("        this.")
                .append(propName)
                .append(" = ")
                .append(propName)
                .append(";\r\n    }\r\n")
                .append("\r\n");
        }
        
        model.addAttribute("serialVersionNum", StringUtil.generate16LongNum());
        model.addAttribute("propertiesStr", sb.toString());
        model.addAttribute("methodStr", sbMethods.toString());
        model.addAttribute("importStr", importStr.toString());
		return null;
	}

	@Override
	public Model generateController(CoderParam param, Model model) {

		//查询模板
		DataModel dataModel = this.dataModelManager.get(param.getModelId());
		
		//查询项目
		Project project = projectManager.get(dataModel.getProject_id());
		
		model.addAttribute("time", DateUtil.toString(new Date(), "yyyy-MM-dd HH:mm:ss"));
		model.addAttribute("packageStr", project.getPackage_name()+Constants.CHARACTER_POINT+PowerType.manager+".api");
        model.addAttribute("username", param.getUsername());
        model.addAttribute("version", dataModel.getVersion());
        model.addAttribute("since", project.getSince());
        model.addAttribute("model", dataModel);
        String s = dataModel.getEnglish_name();
        String className = (new StringBuilder()).append(Character.toUpperCase(s.charAt(0))).append(s.substring(1)).toString();
        model.addAttribute("className", className);
		
        StringBuffer importStr = new StringBuffer();
        importStr.append("import "+project.getPackage_name()+Constants.CHARACTER_POINT+PowerType.core+Constants.CHARACTER_POINT
				+param.getPackageName()+".model.po."+className+";\r\n");
        importStr.append("import "+project.getPackage_name()+Constants.CHARACTER_POINT+PowerType.core+Constants.CHARACTER_POINT
				+param.getPackageName()+".service.I"+className+"Manager;");
        model.addAttribute("importStr", importStr);
        
        model.addAttribute("apiPath", "/"+param.getPackageName());
		
		return null;
	}

	@Override
	public Model generateService(CoderParam param, Model model) {

		//查询模板
		DataModel dataModel = this.dataModelManager.get(param.getModelId());
		
		//查询项目
		Project project = projectManager.get(dataModel.getProject_id());
		
		model.addAttribute("time", DateUtil.toString(new Date(), "yyyy-MM-dd HH:mm:ss"));
		model.addAttribute("packageStr", project.getPackage_name()+Constants.CHARACTER_POINT+PowerType.core+Constants.CHARACTER_POINT
				+param.getPackageName()+".service.impl");
        model.addAttribute("username", param.getUsername());
        model.addAttribute("version", dataModel.getVersion());
        model.addAttribute("since", project.getSince());
        model.addAttribute("model", dataModel);
        String s = dataModel.getEnglish_name();
        String className = (new StringBuilder()).append(Character.toUpperCase(s.charAt(0))).append(s.substring(1)).toString();
        model.addAttribute("className", className);
        
        StringBuffer importStr = new StringBuffer();
        importStr.append("import "+project.getPackage_name()+Constants.CHARACTER_POINT+PowerType.core+Constants.CHARACTER_POINT
				+param.getPackageName()+".model.po."+className+";\r\n");
        importStr.append("import "+project.getPackage_name()+Constants.CHARACTER_POINT+PowerType.core+Constants.CHARACTER_POINT
				+param.getPackageName()+".service.I"+className+"Manager;");
        model.addAttribute("importStr", importStr);
		
		return null;
	}

	@Override
	public void generateInterfaceService(CoderParam param, Model model) {
		//查询模板
		DataModel dataModel = this.dataModelManager.get(param.getModelId());
		
		//查询项目
		Project project = projectManager.get(dataModel.getProject_id());
		
		model.addAttribute("time", DateUtil.toString(new Date(), "yyyy-MM-dd HH:mm:ss"));
		model.addAttribute("packageStr", project.getPackage_name()+Constants.CHARACTER_POINT+PowerType.core+Constants.CHARACTER_POINT
				+param.getPackageName()+".service");
        model.addAttribute("username", param.getUsername());
        model.addAttribute("model", dataModel);
        model.addAttribute("version", dataModel.getVersion());
        model.addAttribute("since", project.getSince());
        
        String s = dataModel.getEnglish_name();
        String className = (new StringBuilder()).append(Character.toUpperCase(s.charAt(0))).append(s.substring(1)).toString();
        model.addAttribute("className", className);
        
        model.addAttribute("importStr", "import "+project.getPackage_name()+Constants.CHARACTER_POINT+PowerType.core+Constants.CHARACTER_POINT
				+param.getPackageName()+".model.po."+className+";");
	
	}


}
